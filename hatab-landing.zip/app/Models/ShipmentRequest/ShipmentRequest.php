<?php

namespace App\Models\ShipmentRequest;

use Illuminate\Database\Eloquent\Model;

class ShipmentRequest extends Model
{

    protected $table = 'shipment_request';

    protected $connection = 'mysql';



}
