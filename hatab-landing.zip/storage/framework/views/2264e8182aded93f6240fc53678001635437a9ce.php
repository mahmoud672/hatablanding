<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <title>حطب</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo e(asset("website/css/bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("website/css/fonts.google-apis.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("website/css/font-awesome.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("website/css/style.css")); ?>">

</head>
<body>
<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center mb-5">
                <h2 class="heading-section">حطب لخدمات الأخشاب</h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="wrapper">

                    <div class="row no-gutters">
                        <div class="col-md-7">
                            <div class="contact-wrap w-100 p-md-5 p-4">
                                <h3 class="mb-4 text-center">تواصل معنا</h3>
                                <div id="form-message-warning" class="mb-4"></div>
                                <div id="form-message-success" class="mb-4">
                                    Your message was sent, thank you!
                                </div>
                                    <?php echo $__env->make("website.messages", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <form method="post" action="<?php echo e(url("/shipment-request/send")); ?>" class="contactForm">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="name">الاسم كامل</label>
                                                <input type="text" class="form-control" name="name" id="name" placeholder="أكتب الاسم كامل" value="<?php echo e(old("name")); ?>">
                                                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="phone">رقم الهاتف</label>
                                                <input type="text" class="form-control" name="phone" id="phone" placeholder="أكتب رقم الهاتف" value="<?php echo e(old("phone")); ?>">
                                                <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="subject">العنوان</label>
                                                <input type="text" class="form-control" name="address" id="address" placeholder="أكتب العنوان" value="<?php echo e(old("address")); ?>">
                                                <?php $__errorArgs = ["address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="label" for="activity">النشاط</label>
                                                <select class="form-control" name="activity" id="activity" >
                                                    <option value="">أختر نشاط</option>
                                                    <option value="بائع حطب"> بائع حطب</option>
                                                    <option value="متجول">متجول</option>
                                                    <option value="محل رحلات">محل رحلات</option>
                                                    <option value="بقالة">بقالة</option>
                                                    <option value="استراحة">استراحة</option>
                                                    <option value="تاجر جملة">تاجر جملة</option>
                                                    <option value="أخرى">أخرى</option>
                                                </select>
                                                <?php $__errorArgs = ["activity"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group ">
                                                <label class="label other-activity" for="other_activity">نشاط آخر</label>
                                                <input type="text" class="form-control other-activity" name="other_activity" id="other_activity" placeholder="أكتب نشاط آخر" value="<?php echo e(old("other_activity")); ?>">
                                                <?php $__errorArgs = ["other_activity"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="label" for="have_sample">استلم عينه</label>
                                                <div class="switch-field">
                                                    <input type="radio" id="radio-one"  name="have_sample" value="1" <?php echo e(old("have_sample") == 1 ? "checked" : ""); ?>/>
                                                    <label for="radio-one">نعم</label>
                                                    <input type="radio" id="radio-two" name="have_sample" value="0" <?php echo e(old("have_sample") == 0 ? "checked" : ""); ?> />
                                                    <label for="radio-two">لا</label>
                                                </div>
                                                <?php $__errorArgs = ["have_sample"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="label" for="offer_value">قيمة العرض المقدم</label>
                                                <input type="number" class="form-control" name="offer_value" id="offer_value" placeholder="أكتب قيمة العرض المقدم" value="<?php echo e(old("offer_value")); ?>">
                                                <?php $__errorArgs = ["offer_value"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                
                                                <div class="rate">
                                                    <input type="radio" id="star5" name="rate" value="5" />
                                                    <label for="star5" title="5"></label>
                                                    <input type="radio" id="star4" name="rate" value="4" />
                                                    <label for="star4" title="4"></label>
                                                    <input type="radio" id="star3" name="rate" value="3" />
                                                    <label for="star3" title="3"></label>
                                                    <input type="radio" id="star2" name="rate" value="2" />
                                                    <label for="star2" title="2"></label>
                                                    <input type="radio" id="star1" name="rate" value="1" />
                                                    <label for="star1" title="1"></label>
                                                </div>
                                            </div>
                                                <?php $__errorArgs = ["rate"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><h6 class="error text-danger error-message"><?php echo e($message); ?></h6> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="label" for="feedback">تقييم</label>
                                                <input type="text" class="form-control" name="feedback" id="feedback" placeholder="أكتب التعليق" value="<?php echo e(old("feedback")); ?>">
                                                <?php $__errorArgs = ["feedback"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="vendor_name">اسم البائع</label>
                                                <input type="text" class="form-control" name="vendor_name" id="name" placeholder="أكتب اسم البائع" value="<?php echo e(old("vendor_name")); ?>">
                                                <?php $__errorArgs = ["vendor_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="notes">ملاحظات</label>
                                                <textarea name="notes" class="form-control" id="notes" cols="30" rows="4" placeholder="أكتب الملاحظات"><?php echo e(old("notes")); ?></textarea>
                                                <?php $__errorArgs = ["notes"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error text-danger error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="submit" value="ارسال" class="btn btn-primary display-flex">
                                                <div class="submitting"></div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-5 d-flex align-items-stretch">
                            <div class="info-wrap w-100 p-5 img" style="background-image: url(<?php echo e(asset("website/images/wood.jpg")); ?>);">
                            </div>
                        </div>

                    </div>
                    <div class="row mb-5 margin-top-5">
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p><span>Address:</span> 198 West 21th Street, Suite 721 New York NY 10016</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p><span>Phone:</span> <a href="tel://1234567920">+ 1235 2355 98</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p><span>Email:</span> <a href="mailto:info@yoursite.com">info@yoursite.com</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-globe"></span>
                                </div>
                                <div class="text">
                                    <p><span>Website</span> <a href="#">yoursite.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<script src="<?php echo e(asset("website/js/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("website/js/popper.js")); ?>"></script>
<script src="<?php echo e(asset("website/js/bootstrap.bundle.min.js")); ?>"></script>
<script src="<?php echo e(asset("website/js/jquery.validate.min.js")); ?>"></script>
<script src="<?php echo e(asset("website/js/main.js")); ?>"></script>
<script src="<?php echo e(asset("website/js/plugin.js")); ?>"></script>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\projects\Harm\hatab-landing\resources\views/welcome.blade.php ENDPATH**/ ?>