



<?php if(Session::has('create')): ?>

    <div class="alert alert-success alert-dismissible" role="alert">
        <h6 class="alert-heading mb-1"><i class="bx bx-xs bx-desktop align-top me-2"></i>Success!</h6>
        <span><?php echo e(session('create')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(Session::has('update')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <h6 class="alert-heading mb-1"><i class="bx bx-xs bx-desktop align-top me-2"></i>Success!</h6>
        <span><?php echo e(session('update')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>


<?php if(Session::has('delete')): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <h6 class="alert-heading mb-1"><i class="bx bx-xs bx-desktop align-top me-2"></i>Alert!</h6>
        <span><?php echo e(session('delete')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>


<?php if(Session::has('exception')): ?>
    <div class="alert alert-warning alert-dismissible" role="alert">
        <h6 class="alert-heading mb-1"><i class="bx bx-xs bx-desktop align-top me-2"></i>Exception!</h6>
        <span><?php echo e(session('exception')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
    <div class="alert alert-warning alert-dismissible" role="alert">
        <h6 class="alert-heading mb-1"><i class="bx bx-xs bx-desktop align-top me-2"></i>Warning!</h6>
        <span><?php echo e(session('warning')); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\projects\Harm\hatab-landing\resources\views/website/messages.blade.php ENDPATH**/ ?>